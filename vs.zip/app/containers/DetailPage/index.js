import React from 'react';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { Layout } from 'antd';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectDetailPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import Navbar from '../../components/Navbar/Loadable';
import Footer from '../../components/Footer/Loadable';
import Content from '../../components/Content/Loadable';

/* eslint-disable react/prefer-stateless-function */
export class DetailPage extends React.Component {
  render() {
    return (
      <div>
        <Helmet>
          <title>DetailPage</title>
          <meta name="description" content="Description of DetailPage" />
        </Helmet>
        <Layout>
          <Navbar />
          <Layout style={{ margin: '100px 0 50px 0' }}>
            <Content />
          </Layout>
          <Footer />
        </Layout>
      </div>
    );
  }
}

DetailPage.propTypes = {
  // dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  detailpage: makeSelectDetailPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'detailPage', reducer });
const withSaga = injectSaga({ key: 'detailPage', saga });

export default compose(
  withReducer,
  withSaga,
  withConnect,
)(DetailPage);
