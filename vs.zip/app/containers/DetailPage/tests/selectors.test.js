// import { fromJS } from 'immutable';
// import { selectDetailPageDomain } from '../selectors';

describe('selectDetailPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
