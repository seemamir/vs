/*
 *
 * DetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/DetailPage/DEFAULT_ACTION';
