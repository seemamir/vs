import styled from 'styled-components';
const Taps = styled.Taps``;
export default Taps;
