/**
 *
 * Draft
 *
 */

import React from 'react';
import { Link } from 'react-router-dom';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

/* eslint-disable react/prefer-stateless-function */
const Draft = ({ children }) => (
  <Link to="/" className="link-draft">
    {children}
  </Link>
);

Draft.propTypes = {};

export default Draft;
