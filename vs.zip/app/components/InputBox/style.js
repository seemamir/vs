import styled from 'styled-components';
const InputBox = styled.Input`
  background-color: red;
`;
export default InputBox;
