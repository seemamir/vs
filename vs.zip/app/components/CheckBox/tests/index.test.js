// import React from 'react';
// import { shallow } from 'enzyme';

// import CheckBox from '../index';

describe('<CheckBox />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
