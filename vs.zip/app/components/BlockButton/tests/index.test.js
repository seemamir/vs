// import React from 'react';
// import { shallow } from 'enzyme';

// import BlockButton from '../index';

describe('<BlockButton />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
